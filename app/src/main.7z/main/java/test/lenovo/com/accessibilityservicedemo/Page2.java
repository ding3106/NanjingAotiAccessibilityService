package test.lenovo.com.accessibilityservicedemo;

import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public class Page2 implements State {
    private static Page2 instance = new Page2();

    private Page2() {

    }

    public static Page2 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE2;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Utils.clickByText(root, "游泳馆", listener);
    }
}
