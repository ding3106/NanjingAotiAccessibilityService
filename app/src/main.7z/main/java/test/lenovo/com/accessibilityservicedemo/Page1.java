package test.lenovo.com.accessibilityservicedemo;

import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public class Page1 implements State {
    private static Page1 instance = new Page1();

    private Page1() {

    }

    public static Page1 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE1;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Utils.clickByText(root, "场地预订", listener);
    }
}
