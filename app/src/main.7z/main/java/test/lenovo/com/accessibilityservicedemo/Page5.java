package test.lenovo.com.accessibilityservicedemo;

import android.util.Log;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/26.
 */

public class Page5 implements State {
    private static Page5 instance = new Page5();

    private Page5() {

    }

    public static Page5 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE5;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Log.d("", "wqy Page5.action() called");
        Utils.clickByText(root, "星期四", listener);
    }
}
