package test.lenovo.com.accessibilityservicedemo;

import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public interface State {
    //return value, true represents succeed,otherwise failed.
    PageOrder getOrder();
    void action(AccessibilityNodeInfo root, ActionListener listener);
}
