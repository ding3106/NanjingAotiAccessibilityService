package test.lenovo.com.accessibilityservicedemo;

import android.util.Log;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/27.
 */

public class Page8 implements State {
    private static Page8 instance = new Page8();

    private Page8() {

    }

    public static Page8 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE8;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Log.d("", "wqy Page8.action() called");
        Utils.clickByText(root, "提交订单", listener);
    }
}
