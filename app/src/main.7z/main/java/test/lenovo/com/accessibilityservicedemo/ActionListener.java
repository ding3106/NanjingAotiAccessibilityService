package test.lenovo.com.accessibilityservicedemo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public interface ActionListener {
    void onActionSucceed();
    void onActionFailed();
}
