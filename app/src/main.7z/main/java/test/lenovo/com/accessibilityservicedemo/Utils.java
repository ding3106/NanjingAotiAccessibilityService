package test.lenovo.com.accessibilityservicedemo;

import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public class Utils {
    private static final String TAG = "Utils";

    public static void DFS(AccessibilityNodeInfo root, String searchText, ActionListener listener) {
            if (root == null || searchText == null) return;
            Log.d(TAG, "wqy DFS called, root="+root.getClassName()+" : " + root.getText() + " count=" + root.getChildCount());
            /*List<AccessibilityNodeInfo> nodeList = root.findAccessibilityNodeInfosByText(searchText);
            if (nodeList.size() > 0) {
                Log.d(TAG, "wqy succeed to find the text:" + searchText);
                //Log.d(TAG, "wqy found node ");
                for (AccessibilityNodeInfo node : nodeList) {
                    Log.d(TAG, "wqy node.getText()" + node.getText());
                    if (node.getText() != null && searchText.equals(node.getText().toString())) {
                        AccessibilityNodeInfo parent = node.getParent();
                        Log.d(TAG, "wqy parent:"+parent.getClassName());
                        if (parent.isClickable()) {
                            Log.d(TAG, "perform click...");
                            parent.performAction((AccessibilityNodeInfo.ACTION_CLICK));
                            listener.onTextSearchSucceed();
                            return;
                        }
                    }
                }

            }*/
            if (root.getText() != null && searchText.equals(root.getText().toString())) {
                //if (!searchText.equals("网络请求中")) {
                    Log.d(TAG, "wqy succeed to find the text:" + searchText + " perform click");
                    root.getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
                //}
                listener.onActionSucceed();
                return;
            } else {
                if (root.getChildCount() != 0) {
                    for (int i = 0; i < root.getChildCount(); i++) {
                        AccessibilityNodeInfo node = root.getChild(i);
                        DFS(node, searchText, listener);
                    }
                }
            }

    }

    public static void clickByText(AccessibilityNodeInfo root, String searchText, ActionListener listener) {
        if (root == null || searchText == null) return;
        Log.d(TAG, "wqy clickText called, root="+root.getClassName()+" : " + root.getText() + " count=" + root.getChildCount());
        List<AccessibilityNodeInfo> nodeList = root.findAccessibilityNodeInfosByText(searchText);
        if (nodeList.size() > 0) {
            Log.d(TAG, "wqy found text:"+searchText);
            nodeList.get(0).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
            listener.onActionSucceed();
        } else {
            Log.d(TAG, "wqy unable to find text:"+searchText);
            listener.onActionFailed();
        }

    }

    public static void clickByViewId(AccessibilityNodeInfo root, String strId, ActionListener listener) {
        if (root == null || strId == null) return;
        Log.d(TAG, "wqy clickText called, root="+root.getClassName()+" : " + root.getText() + " count=" + root.getChildCount());
        List<AccessibilityNodeInfo> nodeList = root.findAccessibilityNodeInfosByViewId(strId);
        if (nodeList.size() > 0) {
            Log.d(TAG, "wqy found id:"+strId);
            nodeList.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            listener.onActionSucceed();
        } else {
            Log.d(TAG, "wqy unable to find text:"+strId);
            listener.onActionFailed();
        }

    }

    public static boolean applyVenues(AccessibilityNodeInfo root) {
        Log.d(TAG, "wqy applyVenues called");
        List<AccessibilityNodeInfo> nodeList = root.findAccessibilityNodeInfosByViewId("com.citycamel.olympic:id/mListView");
        if (nodeList.size() > 0) {
            Log.d(TAG, "wqy found mListView");
            AccessibilityNodeInfo listView = nodeList.get(0);
            Log.d(TAG, "wqy There are " + listView.getChildCount() + " venues");
            for (int i = 0; i < listView.getChildCount(); i++) {
                AccessibilityNodeInfo row = listView.getChild(i);
                Log.d(TAG, "wqy row.classNmae=" + row.getClassName());
                nodeList = row.findAccessibilityNodeInfosByViewId("com.citycamel.olympic:id/venues_list");
                if (nodeList.size() > 0) {
                    Log.d(TAG, "wqy found id:venues_list");
                    AccessibilityNodeInfo gridView = nodeList.get(0);
                    Log.d(TAG, "wqy there are " + gridView.getChildCount() + "time slot");
                    //if (gridView.getChildCount() == 12) {//total 12h
                    List<AccessibilityNodeInfo> foundNodes = gridView.getChild(gridView.getChildCount() - 8).findAccessibilityNodeInfosByText("35");//19:00-20:00
                    List<AccessibilityNodeInfo> foundNodes1 = gridView.getChild(gridView.getChildCount() - 7).findAccessibilityNodeInfosByText("35");//20:00-21:00
                    if (foundNodes.size() > 0 && foundNodes1.size() > 0) { //Two venues available
                        Log.d(TAG, "wqy found 2 free venues!");
                        foundNodes.get(0).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        foundNodes1.get(0).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        List<AccessibilityNodeInfo> totalNumber = root.findAccessibilityNodeInfosByViewId("com.citycamel.olympic:id/total_number");
                        if (totalNumber.size() > 0) {
                            String strPrice = totalNumber.get(0).getText().toString();//$40
                            Log.d(TAG, "wqy total price is:" + strPrice);
                            int price = Integer.valueOf(strPrice.substring(2));
                            Log.d(TAG, "wqy price:" + price);
                            if (price == 70) { //confirm 2 venues has been selected
                                List<AccessibilityNodeInfo> submit = root.findAccessibilityNodeInfosByViewId("com.citycamel.olympic:id/btn_submit");
                                if (submit.size() > 0) {
                                    Log.d(TAG, "wqy 2 venues ready for submit");
                                    submit.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                    /*List<AccessibilityNodeInfo> confirm = root.findAccessibilityNodeInfosByText("确定");
                                    if (confirm.size() > 0) {
                                        Log.d(TAG, "wqy found confirm dialog");
                                        confirm.get(0).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                    }*/
                                    return true;
                                }
                            }
                        }
                    } else {
                        Log.d(TAG, "wqy no 2 free venues!, try again..");
                    }
                    //}
                }
            }
        }

        /*String[] venueList = new String[]{"1号场", "2号场", "3号场", "4号场", "5号场", "6号场", "11号场"};
        for(String venue:venueList) {
            List<AccessibilityNodeInfo> nodeList = root.findAccessibilityNodeInfosByText(venue);
            if (nodeList.size() > 0) {
                Log.d(TAG, "wqy found text:" + venue + " classname="+nodeList.get(0).getClassName());
                AccessibilityNodeInfo node = nodeList.get(0).getParent();
                Log.d(TAG, "wqy " + venue+" parent.parent.classname=" + node.getClassName());
                if ("android.widget.LinearLayout".equals(node.getClassName())) {
                    nodeList = node.findAccessibilityNodeInfosByViewId("venues_list");
                    if (nodeList.size() > 0) {
                        Log.d(TAG, "wqy found id:venues_list at " + venue);
                        AccessibilityNodeInfo gridView = nodeList.get(0);
                        if (gridView.getChildCount() == 12) {//total 12h
                            List<AccessibilityNodeInfo> foundNodes = gridView.getChild(10).findAccessibilityNodeInfosByText("55");//19:00-20:00
                            List<AccessibilityNodeInfo> foundNodes1 = gridView.getChild(11).findAccessibilityNodeInfosByText("55");//20:00-21:00
                            if (foundNodes.size() > 0 && foundNodes1.size() > 0) { //Two venues available
                                Log.d(TAG, "wqy found 2 free venues!");
                                foundNodes.get(0).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                foundNodes1.get(0).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                List<AccessibilityNodeInfo> totalNumber = root.findAccessibilityNodeInfosByViewId("total_number");
                                if (totalNumber.size() > 0) {
                                    String price = totalNumber.get(0).getText().toString();//$40
                                    Log.d(TAG, "total price is:" + price);
                                    price = price.substring(1);
                                    if (price.equals("110")) { //confirm 2 venues has been selected
                                        List<AccessibilityNodeInfo> submit = root.findAccessibilityNodeInfosByViewId("btn_submit");
                                        if (submit.size() > 0) {
                                            Log.d(TAG, "wqy 2 venues ready for submit");
                                            submit.get(0).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }*/
        return false;
    }

    /*private static boolean searchText(AccessibilityNodeInfo root, String text) {
        if (root == null || searchText == null) return false;
        Log.d(TAG, "wqy searchText called, root="+root.getClassName()+" : " + root.getText() + " count=" + root.getChildCount());
            /*List<AccessibilityNodeInfo> nodeList = root.findAccessibilityNodeInfosByText(searchText);
            if (nodeList.size() > 0) {
    }*/
}
