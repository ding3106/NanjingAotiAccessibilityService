package test.lenovo.com.accessibilityservicedemo;

import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public class Page4 implements State {
    private static Page4 instance = new Page4();

    private Page4() {

    }

    public static Page4 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE4;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Utils.clickByText(root, "网络请求中", listener);
    }
}
