package test.lenovo.com.accessibilityservicedemo;

import android.accessibilityservice.AccessibilityService;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MyAccessibilityService extends AccessibilityService implements Context {
    private final static String TAG = "MyAccessibilityService";

    private State currentState = Page1.getInstance();

    private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.sss");//设置日期格式
//System.out.println(df.format(new Date()));// new Date()为获取当前系统时间

    public MyAccessibilityService() {
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        Log.d(TAG, "wqy onAccessibilityEvent called,time:"+ df.format(new Date())+" event.getSource:"+event.getSource());
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();

            if (root == null) {
                Log.d(TAG, "wqy root == null, return");
                return;
            }
            /*if (currentState.getOrder() == PageOrder.PAGE5) {
                List<AccessibilityWindowInfo> windowList = getWindows();
                for (AccessibilityWindowInfo window : windowList) {
                    currentState.action(window.getRoot(), new TextSearchListener() {
                        @Override
                        public void onTextSearchSucceed() {
                            changeState();
                        }
                    });
                }
            } else {*/
                currentState.action(root, new ActionListener() {
                    @Override
                    public void onActionSucceed() {
                        nextState();
                    }

                    @Override
                    public void onActionFailed() {
                        preState();
                    }
                });
            //}
        } catch (Exception e) {
            Log.d(TAG, "wqy Exception occurred:" + e.getMessage());
        }

        //DFS(root);
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "wqy onInterrupt() called");
    }

    @Override
    public void nextState() {
        Log.d(TAG, "wqy nextState() called,current state:" + currentState.getOrder().toString());
        switch(currentState.getOrder()) {
            case PAGE1:
                currentState = Page2.getInstance();
                break;
            case PAGE2:
                currentState =Page3.getInstance();
                break;
            case PAGE3:
                currentState = Page4.getInstance();
                break;
            case PAGE4:
                currentState = Page5.getInstance();
                break;
            case PAGE5:
                currentState = Page6.getInstance();
                break;
            case PAGE6:
                currentState = Page7.getInstance();
                break;
            case PAGE7:
                currentState = Page8.getInstance();
                break;
            default:
                break;
        }
    }

    @Override
    public void preState() {

    }


    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "wqy onUnbind() called");
        return true;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "wqy onDestroy() called");
    }


    /*@Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }*/
}
