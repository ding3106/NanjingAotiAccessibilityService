package test.lenovo.com.accessibilityservicedemo;

import android.util.Log;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/27.
 */

public class Page6 implements State {
    private static Page6 instance = new Page6();

    private Page6() {

    }

    public static Page6 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE6;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Log.d("", "wqy Page6.action() called");
        if (Utils.applyVenues(root)) {
            listener.onActionSucceed();
        } else {
            listener.onActionFailed();
        }
        //scroll right
        //select
        //Utils.DFS(root, "星期五", listener);
    }
}
