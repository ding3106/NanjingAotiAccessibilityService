package test.lenovo.com.accessibilityservicedemo;

import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public class Page3 implements State {
    private static Page3 instance = new Page3();

    private Page3() {

    }

    public static Page3 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE3;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Utils.clickByText(root, "游泳馆羽毛球", listener);
    }
}
