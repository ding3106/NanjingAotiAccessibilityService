package test.lenovo.com.accessibilityservicedemo;

import android.util.Log;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Created by wangqy5 on 2018/7/27.
 */

public class Page7 implements State{
    private static Page7 instance = new Page7();

    private Page7() {

    }

    public static Page7 getInstance() {
        return instance;
    }

    @Override
    public PageOrder getOrder() {
        return PageOrder.PAGE7;
    }

    @Override
    public void action(AccessibilityNodeInfo root, ActionListener listener) {
        Log.d("", "wqy Page7.action() called");
        //Utils.clickByText(root, "确定", listener);
        Utils.clickByViewId(root, "com.citycamel.olympic:id/confirm_btn", listener);
        /*if (Utils.applyVenues(root)) {
            listener.nextState();
        } else {
            listener.preState();
        }*/

    }
}
