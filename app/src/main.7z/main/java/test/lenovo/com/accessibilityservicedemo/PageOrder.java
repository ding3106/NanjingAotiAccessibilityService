package test.lenovo.com.accessibilityservicedemo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public enum PageOrder {
    PAGE1,
    PAGE2,
    PAGE3,
    PAGE4,
    PAGE5,
    PAGE6,
    PAGE7,
    PAGE8,
    NULL
}
