package test.lenovo.com.accessibilityservicedemo;

/**
 * Created by wangqy5 on 2018/7/25.
 */

public interface Context {
    void nextState();
    void preState();
}
